//
//  ViewController.m
//  XML PARSING
//
//  Created by Student P_04 on 31/08/17.
//  Copyright © 2017 RAJ. All rights reserved.
//

#import "ViewController.h"
#import "Table.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self parseXML];
    //NSLog(@"%@",TableArray);
    // Do any additional setup after loading the view, typically from a nib.
}
-(void)parseXML{
    TableArray=[[NSMutableArray alloc]init];
    NSURL *url=[[NSBundle mainBundle]URLForResource:@"codebeautify" withExtension:@"xml"];
    parser=[[NSXMLParser alloc]initWithContentsOfURL:url];
    parser.delegate=self;
    [parser parse];
    for (int i =0; i<TableArray.count; i++) {
        Table *tbl = [TableArray objectAtIndex:i];
        NSLog(@"%@",tbl.Name);
        NSLog(@"%@",tbl.CountryCode);
        NSLog(@"%@",tbl.Currency);
        NSLog(@"%@",tbl.CurrencyCode);
    }
    
}
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(nullable NSString *)namespaceURI qualifiedName:(nullable NSString *)qName attributes:(NSDictionary<NSString *, NSString *> *)attributeDict{
   
    
    if ([elementName isEqualToString:@"Table"]) {
        t=[[Table alloc]init];
    
    }
    else if ([elementName isEqualToString:@"Name"])
    {
        dataStr=[[NSMutableString alloc]init];

    }
    else if ([elementName isEqualToString:@"CountryCode"])
    {
        dataStr=[[NSMutableString alloc]init];
    }
    else if ([elementName isEqualToString:@"Currency"])
    {
        dataStr=[[NSMutableString alloc]init];
    }
    else if ([elementName isEqualToString:@"CurrencyCode"])
    {
        dataStr=[[NSMutableString alloc]init];
    }


}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    [dataStr appendString:string];
    }


- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(nullable NSString *)namespaceURI qualifiedName:(nullable NSString *)qName{
    if ([elementName isEqualToString:@"Name"]) {
        t.Name=dataStr;
    }
else if ([elementName isEqualToString:@"CountryCode"])
{
    t.CountryCode=dataStr;
}
else if ([elementName isEqualToString:@"Currency"])
{
    t.Currency=dataStr;
}
else if ([elementName isEqualToString:@"CurrencyCode"])
{
    t.CurrencyCode=dataStr;
}

else if ([elementName isEqualToString:@"Table"])
{
    [TableArray addObject:t];
    
}

}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return TableArray.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId=@"cell";
    UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    
    Table *table=[TableArray objectAtIndex:indexPath.row];
    cell.textLabel.text=table.Name;
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
