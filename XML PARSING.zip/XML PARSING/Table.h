//
//  Table.h
//  XML PARSING
//
//  Created by Student P_04 on 31/08/17.
//  Copyright © 2017 RAJ. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Table : NSObject
@property(nonatomic,retain)NSString *Name;
@property(nonatomic,retain)NSString *CountryCode;
@property(nonatomic,retain)NSString *Currency;
@property(nonatomic,retain)NSString *CurrencyCode;
@end
